package service;

import java.math.BigDecimal;
import java.util.List;
// import model.Snack;
import model.Soda;

/**
 *
 * @author NA342393
 */
public interface SodaService {
    
    public void addMoney(String amount);
    
    public void makePurchase();
    
    public void changeReturn();

    BigDecimal getBalance();

    String getMessage();

    Change getMyChange();

    int getSelection();

    Soda getSodaById(int id);

    List<Soda> getSodas();

    void setBalance(BigDecimal balance);

    void setMessage(String message);

    void setMyChange(Change myChange);

    void setSelection(int Selection);
    
}
