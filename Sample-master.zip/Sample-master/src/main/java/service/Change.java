package service;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 *
 * @author NA342393
 */
public class Change {
    private int quarters;
    private int pennies;
    
    public Change(BigDecimal balance) {
        pennies = Integer.parseInt(balance.toString().replace(".", ""));
        quarters = pennies / 25;
     }

    public int getQuarters() {
        return quarters;
    }    
}
