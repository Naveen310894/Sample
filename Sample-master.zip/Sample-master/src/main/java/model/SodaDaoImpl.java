package model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 *
 * @author NA342393
 */
public class SodaDaoImpl implements SodaDao {
    HashMap<Integer,Soda> sodas;
    
    public SodaDaoImpl() {
        sodas = new HashMap<>();
        sodas.put(1, new Soda(1,"Coke",new BigDecimal("1"),5));
        sodas.put(2, new Soda(2,"Pepsi",new BigDecimal("2"),5));
        sodas.put(3, new Soda(3,"Thumsup",new BigDecimal("3"),5));
        sodas.put(4, new Soda(4,"Dew",new BigDecimal("1.50"),5));
            
    }

    @Override
    public Soda getSodaById(int id) {
        return sodas.get(id);
    }

    @Override
    public List<Soda> getSodas() {
        return new ArrayList<>(sodas.values());
    }
    
}
