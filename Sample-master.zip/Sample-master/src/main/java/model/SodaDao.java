package model;

import java.util.List;

/**
 *
 * @author NA342393
 */
public interface SodaDao {
    public Soda getSodaById(int id);
    public List<Soda> getSodas();
}
